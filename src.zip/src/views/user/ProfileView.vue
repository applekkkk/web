<script setup>
import { computed, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import DatasetCard from "../../components/DatasetCard.vue";
import NeedCard from "../../components/NeedCard.vue";
import { useAuthStore } from "../../stores/auth";
import { customRequestApi, orderApi, productApi, taskAppealApi } from "../../services/api";

const route = useRoute();
const router = useRouter();
const auth = useAuthStore();

const tabs = ["收藏", "个人仓库", "我的数据", "我的订单", "我的申诉", "发布任务", "承接任务"];
const datasetTabs = ["收藏", "个人仓库", "我的数据"];
const needTabs = ["发布任务", "承接任务"];
const orderTabs = ["我的订单"];
const appealTabs = ["我的申诉"];

const activeTab = ref(tabs[0]);
const purchasedDatasets = ref([]);
const myDatasets = ref([]);
const favoriteDatasets = ref([]);
const publishedNeeds = ref([]);
const acceptedNeeds = ref([]);
const orders = ref([]);
const appeals = ref([]);

const datasetLoading = ref(false);
const needsLoading = ref(false);
const ordersLoading = ref(false);
const appealsLoading = ref(false);

const userName = computed(() => auth.user?.name || "未命名用户");
const userPoints = computed(() => Number(auth.user?.points ?? 0));
const userInitial = computed(() => {
  const raw = String(auth.user?.name || "U").trim();
  return raw ? raw.slice(0, 1).toUpperCase() : "U";
});
const userId = computed(() => auth.user?.id ?? null);
const userBio = computed(() => auth.user?.bio || "快来介绍一下自己");
const today = computed(() => new Date().toISOString().slice(0, 10));

const tabDatasets = computed(() => {
  if (activeTab.value === "收藏") return favoriteDatasets.value;
  if (activeTab.value === "个人仓库") return purchasedDatasets.value;
  if (activeTab.value === "我的数据") return myDatasets.value;
  return [];
});

const tabNeeds = computed(() => {
  if (activeTab.value === "发布任务") return publishedNeeds.value;
  if (activeTab.value === "承接任务") return acceptedNeeds.value;
  return [];
});

const displayOrders = computed(() => orders.value.map(normalizeOrder));
const displayAppeals = computed(() => appeals.value.map(normalizeAppeal));

watch(
  () => route.query.tab,
  (tab) => {
    const value = String(tab || "");
    if (tabs.includes(value)) activeTab.value = value;
  },
  { immediate: true }
);

watch(
  [activeTab, userId],
  async () => {
    await loadTabData();
  },
  { immediate: true }
);

function normalizeProduct(item) {
  return {
    ...item,
    id: item.id,
    name: item.name || "",
    info: item.info || "",
    category: item.category || "其他",
    tags: item.tags || "",
    price: Number(item.price || 0),
    size: item?.size ?? item?.sizeLabel ?? item?.size_label ?? "-",
    author: item?.author ?? item?.authorName ?? item?.author_name ?? item?.seller ?? "",
    uploadDate: item?.uploadDate ?? item?.upload_date ?? "",
    purchased: Boolean(item.purchased),
    likes: Number(item.likes || 0),
    stars: Number(item.stars || 0),
    downloads: Number(item.downloads || 0),
    liked: Boolean(item.liked),
    favorited: Boolean(item.favorited),
    fileName: item.fileName ?? item.file_name ?? ""
  };
}

function normalizeNeed(item) {
  const statusCode = Number(item.needStatus ?? item.need_status ?? 0);
  let statusText = "未承接";
  if (statusCode === 1) statusText = "进行中";
  if (statusCode === 2) statusText = "待发布者确认";
  if (statusCode === 3) statusText = "已完成";
  return {
    id: item.id,
    title: item.title || "",
    description: item.description || "",
    category: item.category || "其他",
    tags: item.tags || "",
    budget: Number(item.budget || 0),
    deadline: item.deadline || "",
    publisher: item.publisherName ?? item.publisher_name ?? "",
    publisherId: item.publisherId ?? item.publisher_id ?? null,
    acceptedBy: item.acceptorName ?? item.acceptor_name ?? "",
    acceptorId: item.acceptorId ?? item.acceptor_id ?? null,
    attachmentName: item.attachmentName ?? item.attachment_name ?? "",
    needStatus: statusText
  };
}

function normalizeOrder(item) {
  const amount = Number(item.amount ?? 0);
  const title = String(item.productName || "");
  const isAiOrder = title.startsWith("AI数据处理:");
  const isDataOrder = title.includes("购买数据") || title.includes("管理员授权购买") || title.includes("管理员申诉退款");
  const isTaskOrder =
    !isAiOrder &&
    ((!isDataOrder && amount >= 0) ||
    title.includes("任务结算支出") ||
    title.includes("任务结算收入") ||
    title.includes("承接任务记录") ||
    (title.includes("任务") && !title.includes("购买数据") && !title.includes("管理员授权购买")));
  const type = isAiOrder ? "AI处理" : isTaskOrder ? "数据定制" : "数据购买";
  const productId = Number(item.productId ?? 0);
  let targetPath = "";
  if (isAiOrder) {
    const no = encodeURIComponent(String(item.orderNo || item.id || ""));
    if (no) targetPath = `/user/processing/result/${no}`;
  } else if (productId > 0) {
    targetPath = isTaskOrder ? `/user/custom-bids/${productId}` : `/user/market/${productId}`;
  }
  return {
    id: item.id,
    orderNo: item.orderNo,
    productId,
    amount,
    type,
    title: title || (isAiOrder ? "AI处理订单" : isTaskOrder ? "数据定制订单" : "数据购买订单"),
    createdAt: formatTime(item.createdAt || ""),
    targetPath
  };
}

function normalizeAppeal(item) {
  const targetType = String(item?.targetType ?? item?.target_type ?? "").toUpperCase();
  const role = String(item?.appellantRole ?? item?.appellant_role ?? "");
  const type = targetType === "DATA" ? "数据" : targetType === "TASK" ? "任务" : role.includes("购买") ? "数据" : "任务";
  return {
    id: Number(item?.id ?? 0),
    requestId: Number(item?.requestId ?? item?.request_id ?? 0),
    title: item?.requestTitle ?? item?.request_title ?? "",
    type,
    status: Number(item?.status ?? 0) === 1 ? "已处理" : "待处理",
    claimText: item?.claimText ?? item?.claim_text ?? "",
    evidenceText:
      item?.evidenceText ?? item?.evidence_text ?? item?.evidenceDesc ?? item?.evidence_desc ?? item?.evidence ?? "",
    evidenceImage:
      item?.evidenceImage ?? item?.evidence_image ?? item?.evidenceUrl ?? item?.evidence_url ?? item?.image ?? "",
    createdAt: formatTime(item?.createdAt ?? item?.created_at ?? "")
  };
}

function formatTime(value) {
  return String(value || "").replace("T", " ");
}

function dedupeProducts(list) {
  const map = new Map();
  list.forEach((item) => {
    if (!item?.id) return;
    if (!map.has(item.id)) map.set(item.id, item);
  });
  return Array.from(map.values());
}

function amountText(amount) {
  return amount > 0 ? `+${amount}` : `${amount}`;
}

function openOrderDetail(order) {
  if (!order?.targetPath) {
    ElMessage.info("该订单暂无可跳转的详情");
    return;
  }
  router.push(order.targetPath);
}

function openAppealDetail(appeal) {
  if (!appeal?.requestId) {
    ElMessage.info("该申诉暂无可跳转详情");
    return;
  }
  if (appeal.type === "数据") {
    router.push(`/user/market/${appeal.requestId}`);
    return;
  }
  router.push(`/user/custom-bids/${appeal.requestId}`);
}

function appealImageUrl(name) {
  const value = String(name || "");
  if (!value) return "";
  if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("/")) return value;
  return `/api/files/download?name=${encodeURIComponent(value)}`;
}
function goEditProfile() {
  router.push(route.path.startsWith("/admin") ? "/admin/profile/edit" : "/user/profile/edit");
}

function goDatasetDetail(id) {
  if (route.path.startsWith("/admin")) return;
  router.push({ path: `/user/market/${id}` });
}

function goNeedDetail(item) {
  if (route.path.startsWith("/admin")) return;
  router.push({ path: `/user/custom-bids/${item.id}` });
}

function purchasedIdSet(orderList) {
  return new Set(
    orderList
      .filter((item) => {
        if (Number(item?.status ?? 1) !== 1) return false;
        const name = String(item?.productName ?? "");
        return name.startsWith("购买数据:") || name.startsWith("管理员授权购买:");
      })
      .map((item) => Number(item.productId))
      .filter((id) => Number.isFinite(id) && id > 0)
  );
}

async function fetchOrders(silent = false) {
  if (!userId.value) return [];
  if (!silent) ordersLoading.value = true;
  try {
    const res = await orderApi.getUserList(userId.value);
    if (res?.code !== 200) {
      throw new Error(res?.message || "加载订单失败");
    }
    const list = Array.isArray(res?.data) ? res.data : [];
    orders.value = list;
    return list;
  } catch (e) {
    orders.value = [];
    if (!silent) ElMessage.error(e?.message || "加载订单失败");
    return [];
  } finally {
    if (!silent) ordersLoading.value = false;
  }
}

async function fetchAppeals(silent = false) {
  if (!userId.value) return;
  if (!silent) appealsLoading.value = true;
  try {
    const res = await taskAppealApi.getUserList(userId.value);
    if (res?.code !== 200) {
      throw new Error(res?.message || "加载申诉失败");
    }
    appeals.value = Array.isArray(res?.data) ? res.data : [];
  } catch (e) {
    appeals.value = [];
    if (!silent) ElMessage.error(e?.message || "加载申诉失败");
  } finally {
    if (!silent) appealsLoading.value = false;
  }
}

async function fetchPurchasedDatasets(sourceOrders) {
  const orderList = Array.isArray(sourceOrders) ? sourceOrders : orders.value;
  const ids = Array.from(purchasedIdSet(orderList));
  if (ids.length === 0) {
    purchasedDatasets.value = [];
    return;
  }

  const tasks = ids.map(async (id) => {
    try {
      const res = await productApi.getById(id, { userId: userId.value });
      if (res?.code !== 200 || !res?.data) return null;
      return normalizeProduct({ ...res.data, purchased: true });
    } catch {
      return null;
    }
  });
  const list = await Promise.all(tasks);
  purchasedDatasets.value = dedupeProducts(list.filter(Boolean));
}

async function fetchFavoriteDatasets(silent = false) {
  if (!userId.value) return;
  if (!silent) datasetLoading.value = true;
  try {
    const [favoriteRes, orderList] = await Promise.all([productApi.getFavoriteProducts(userId.value), fetchOrders(true)]);
    if (favoriteRes?.code !== 200) {
      throw new Error(favoriteRes?.message || "加载收藏失败");
    }
    const purchasedSet = purchasedIdSet(orderList);
    const list = Array.isArray(favoriteRes?.data) ? favoriteRes.data : [];
    favoriteDatasets.value = list.map((item) =>
      normalizeProduct({
        ...item,
        purchased: purchasedSet.has(Number(item.id))
      })
    );
  } catch (e) {
    favoriteDatasets.value = [];
    if (!silent) ElMessage.error(e?.message || "加载收藏失败");
  } finally {
    if (!silent) datasetLoading.value = false;
  }
}

async function fetchMyDatasets(silent = false) {
  if (!userId.value) return;
  if (!silent) datasetLoading.value = true;
  try {
    const res = await productApi.getUserProducts(userId.value);
    if (res?.code !== 200) {
      throw new Error(res?.message || "加载我的数据失败");
    }
    const list = Array.isArray(res?.data) ? res.data : [];
    myDatasets.value = list.map((item) => normalizeProduct(item));
  } catch (e) {
    myDatasets.value = [];
    if (!silent) ElMessage.error(e?.message || "加载我的数据失败");
  } finally {
    if (!silent) datasetLoading.value = false;
  }
}

async function fetchNeeds(silent = false) {
  if (!userId.value) return;
  if (!silent) needsLoading.value = true;
  try {
    const [publishedRes, allRes] = await Promise.all([customRequestApi.getUserList(userId.value), customRequestApi.getAll()]);
    if (publishedRes?.code !== 200) {
      throw new Error(publishedRes?.message || "加载任务失败");
    }
    if (allRes?.code !== 200) {
      throw new Error(allRes?.message || "加载任务失败");
    }
    const publishedList = Array.isArray(publishedRes?.data) ? publishedRes.data : [];
    const allList = Array.isArray(allRes?.data) ? allRes.data : [];
    publishedNeeds.value = publishedList.map(normalizeNeed);
    acceptedNeeds.value = allList
      .filter((item) => Number(item.acceptorId ?? item.acceptor_id ?? 0) === Number(userId.value))
      .map(normalizeNeed);
  } catch (e) {
    publishedNeeds.value = [];
    acceptedNeeds.value = [];
    if (!silent) ElMessage.error(e?.message || "加载任务失败");
  } finally {
    if (!silent) needsLoading.value = false;
  }
}

async function loadTabData() {
  if (!userId.value) return;
  if (orderTabs.includes(activeTab.value)) {
    await fetchOrders(false);
    return;
  }
  if (appealTabs.includes(activeTab.value)) {
    await fetchAppeals(false);
    return;
  }
  if (activeTab.value === "个人仓库") {
    datasetLoading.value = true;
    const orderList = await fetchOrders(true);
    await fetchPurchasedDatasets(orderList);
    datasetLoading.value = false;
    return;
  }
  if (activeTab.value === "我的数据") {
    await fetchMyDatasets(false);
    return;
  }
  if (activeTab.value === "收藏") {
    await fetchFavoriteDatasets(false);
    return;
  }
  if (needTabs.includes(activeTab.value)) {
    await fetchNeeds(false);
  }
}

async function toggleLike(item) {
  if (!auth.user?.id) {
    ElMessage.warning("请先登录");
    return;
  }
  try {
    const res = await productApi.setLike(item.id, auth.user.id, !item.liked);
    if (res?.code !== 200 || !res?.data) {
      throw new Error(res?.message || "点赞失败");
    }
    item.likes = Number(res.data.likes ?? 0);
    item.stars = Number(res.data.stars ?? item.stars ?? 0);
    item.liked = Boolean(res.data.liked);
    item.favorited = Boolean(res.data.favorited);
  } catch (e) {
    ElMessage.error(e?.message || "点赞失败");
  }
}

async function toggleFavorite(item) {
  if (!auth.user?.id) {
    ElMessage.warning("请先登录");
    return;
  }
  try {
    const res = await productApi.setFavorite(item.id, auth.user.id, !item.favorited);
    if (res?.code !== 200 || !res?.data) {
      throw new Error(res?.message || "收藏失败");
    }
    item.likes = Number(res.data.likes ?? item.likes ?? 0);
    item.stars = Number(res.data.stars ?? 0);
    item.liked = Boolean(res.data.liked);
    item.favorited = Boolean(res.data.favorited);
    if (activeTab.value === "收藏" && !item.favorited) {
      favoriteDatasets.value = favoriteDatasets.value.filter((dataset) => dataset.id !== item.id);
    }
  } catch (e) {
    ElMessage.error(e?.message || "收藏失败");
  }
}

function handleDownload(item) {
  if (!item.purchased) {
    ElMessage.warning("未购买");
    return;
  }
  item.downloads = (item.downloads ?? 0) + 1;
  ElMessage.success("下载成功");
}
</script>

<template>
  <section class="profile-page">
    <header class="profile-head">
      <span class="avatar-initial">{{ userInitial }}</span>
      <div class="head-main">
        <h1>{{ userName }}</h1>
        <p class="intro">{{ userBio }}</p>
      </div>
      <div class="head-right">
        <span class="points">积分：{{ userPoints }}</span>
        <span class="last-login">上次登录时间：{{ today }}</span>
        <button class="edit-btn" @click="goEditProfile">编辑个人资料</button>
      </div>
    </header>

    <div class="tabs">
      <button
        v-for="tab in tabs"
        :key="tab"
        type="button"
        class="tab-btn"
        :class="{ active: activeTab === tab }"
        @click="activeTab = tab"
      >
        {{ tab }}
      </button>
    </div>

    <template v-if="datasetTabs.includes(activeTab)">
      <section v-loading="datasetLoading">
        <section v-if="tabDatasets.length" class="cards-grid">
          <DatasetCard
            v-for="(item, idx) in tabDatasets"
            :key="item.id"
            :item="item"
            :style="{ '--stagger': idx }"
            @open="goDatasetDetail(item.id)"
            @like="toggleLike"
            @favorite="toggleFavorite"
            @download="handleDownload"
          />
        </section>
        <p v-else class="empty-text">当前栏目暂无数据。</p>
      </section>
    </template>

    <template v-else-if="needTabs.includes(activeTab)">
      <section v-loading="needsLoading">
        <section v-if="tabNeeds.length" class="cards-grid">
          <NeedCard
            v-for="(item, idx) in tabNeeds"
            :key="item.id"
            :item="item"
            :style="{ '--stagger': idx }"
            :show-action="false"
            clickable
            @open="goNeedDetail"
          />
        </section>
        <p v-else class="empty-text">当前栏目暂无任务。</p>
      </section>
    </template>

    <template v-else-if="orderTabs.includes(activeTab)">
      <section class="orders-card" v-loading="ordersLoading">
        <table>
          <thead>
            <tr>
              <th>订单号</th>
              <th>类型</th>
              <th>内容</th>
              <th>积分变动</th>
              <th>时间</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in displayOrders"
              :key="item.id"
              :class="{ clickable: Boolean(item.targetPath) }"
              @click="openOrderDetail(item)"
            >
              <td>{{ item.orderNo || item.id }}</td>
              <td>{{ item.type }}</td>
              <td>{{ item.title }}</td>
              <td :class="item.amount >= 0 ? 'amount plus' : 'amount minus'">
                {{ amountText(item.amount) }}
              </td>
              <td>{{ item.createdAt }}</td>
            </tr>
          </tbody>
        </table>
        <p v-if="!ordersLoading && displayOrders.length === 0" class="empty-text">当前栏目暂无订单。</p>
      </section>
    </template>

    <template v-else-if="appealTabs.includes(activeTab)">
      <section class="orders-card" v-loading="appealsLoading">
        <table>
          <thead>
            <tr>
              <th>申诉ID</th>
              <th>类型</th>
              <th>目标</th>
              <th>申诉理由</th>
              <th>证据说明</th>
              <th>证据图片</th>
              <th>状态</th>
              <th>时间</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in displayAppeals"
              :key="item.id"
              :class="{ clickable: Boolean(item.requestId) }"
              @click="openAppealDetail(item)"
            >
              <td>{{ item.id }}</td>
              <td>{{ item.type }}</td>
              <td>{{ item.title || `记录#${item.requestId}` }}</td>
              <td class="appeal-claim">{{ item.claimText || "-" }}</td>
              <td class="appeal-claim">{{ item.evidenceText || "-" }}</td>
              <td>
                <img
                  v-if="item.evidenceImage"
                  class="appeal-evidence-img"
                  :src="appealImageUrl(item.evidenceImage)"
                  alt="证据图片"
                />
                <span v-else>-</span>
              </td>
              <td>
                <span class="status-pill" :class="{ done: item.status === '已处理' }">{{ item.status }}</span>
              </td>
              <td>{{ item.createdAt }}</td>
            </tr>
          </tbody>
        </table>
        <p v-if="!appealsLoading && displayAppeals.length === 0" class="empty-text">当前栏目暂无申诉记录。</p>
      </section>
    </template>

    <p v-else class="content-tip">该栏目内容正在建设中。</p>
  </section>
</template>

<style scoped>
.profile-page {
  display: grid;
  gap: 16px;
}

.profile-head {
  display: grid;
  grid-template-columns: auto 1fr auto;
  gap: 18px;
  align-items: center;
  border-radius: 18px;
  padding: 20px 24px;
  background: linear-gradient(145deg, #e8f0fb, #f3f7ff);
  border: 1px solid #d9e4f5;
}

.avatar-initial {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 78px;
  height: 78px;
  border-radius: 50%;
  color: #eef4ff;
  font-size: 34px;
  font-weight: 700;
  background: linear-gradient(135deg, #6f80ff, #5d63f0);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22);
}

.head-main h1 {
  margin: 0;
  color: #1f2a37;
  font-size: 40px;
}

.intro {
  margin: 10px 0 0;
  color: #8a96a6;
}

.head-right {
  display: grid;
  justify-items: end;
  gap: 12px;
}

.last-login {
  color: #8091a8;
  font-size: 14px;
}

.points {
  color: #2f578d;
  font-size: 14px;
  font-weight: 600;
}

.edit-btn {
  border: 1px solid #c3d3ee;
  border-radius: 999px;
  padding: 8px 18px;
  color: #2f578d;
  background: #fff;
  cursor: pointer;
}

.tabs {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  border-bottom: 1px solid #e6e9ef;
  padding-bottom: 10px;
}

.tab-btn {
  border: none;
  background: transparent;
  color: #3f4b5c;
  padding: 8px 12px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
}

.tab-btn.active {
  color: #2c7cf6;
  border-bottom-color: #2c7cf6;
}

.content-tip {
  margin: 10px 0 0;
  color: #718096;
}

.cards-grid {
  margin-top: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.orders-card {
  margin-top: 10px;
  border: 1px solid #e4ebf6;
  border-radius: 16px;
  padding: 14px 16px;
  background: #fff;
  box-shadow: 0 10px 24px rgba(16, 24, 40, 0.05);
}

.orders-card table {
  width: 100%;
  border-collapse: collapse;
}

.orders-card th,
.orders-card td {
  border-bottom: 1px solid #e5ecf7;
  padding: 10px 8px;
  text-align: left;
  font-size: 13px;
}

.orders-card tbody tr.clickable {
  cursor: pointer;
}

.orders-card tbody tr.clickable:hover td {
  background: #f7fbff;
}

.appeal-claim {
  max-width: 280px;
  white-space: normal;
  word-break: break-word;
}

.appeal-evidence-img {
  width: 64px;
  height: 64px;
  object-fit: cover;
  border: 1px solid #dce4f1;
  border-radius: 8px;
}

.status-pill {
  display: inline-block;
  border: 1px solid #9fc2ef;
  border-radius: 999px;
  padding: 2px 10px;
  color: #2f5a90;
  background: rgba(47, 90, 144, 0.12);
}

.status-pill.done {
  border-color: #7bd69d;
  color: #2d8a4d;
  background: rgba(58, 170, 93, 0.12);
}

.amount.plus {
  color: #2a7a3f;
}

.amount.minus {
  color: #a74141;
}

.empty-text {
  color: #7b8797;
}

@media (max-width: 900px) {
  .profile-head {
    grid-template-columns: 1fr;
    justify-items: start;
  }

  .head-right {
    justify-items: start;
  }
}
</style>
